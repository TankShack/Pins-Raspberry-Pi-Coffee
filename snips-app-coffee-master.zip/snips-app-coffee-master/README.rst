===============================
Snips App Coffee Hack
===============================

Snips action code for your Hacked Coffee Machine.
Here the instructions to make this hack.

Features
--------

turn on and off the coffee machine.
brew one or two coffee
brew one or two long coffee
brew a strong coffee

Copyright
---------

This action code is provided by `Snips <https://www.snips.ai>`_ as Open Source
software. See `LICENSE.txt
<https://github.com/snipsco/snips-skill-coffee/blob/master/LICENSE.txt>`_ for more
information.
